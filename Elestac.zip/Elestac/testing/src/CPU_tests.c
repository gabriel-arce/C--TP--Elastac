/*
 * CPU_tests.c
 *
 *  Created on: 9/6/2016
 *      Author: utnso
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <commons/config.h>
#include <commons/collections/list.h>
#include <commons/string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <elestac_config.h>
#include <elestac_sockets.h>
#include <parser/metadata_program.h>
#include <parser/parser.h>
#include <elestac_pcb.h>
#include <assert.h>
#include <string.h>
#include <commons/collections/list.h>
#include <commons/string.h>

int main(){

	return EXIT_SUCCESS;
}
